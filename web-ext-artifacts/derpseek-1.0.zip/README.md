##DAFUQ?

Derpseek is just a clipboard for your AI prompt.

Ahh also (as a feature) maybe your chabot page will be a lil' derpy.

![DerpSearch loggin page](doc/image.png)

#Never give you up, Never let you down